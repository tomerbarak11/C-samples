/*************************************************************************
* 						PROGRAMMER: Tomer Barak
* 						FILE: bubbleShakeQuick code
* 						DATE: 11-07-2019 15:00:57
*******************************************************************************/

#include <stdio.h> 		/* printf                                       */
#include <stdlib.h> 	    /* EXIT_SUCCESS, EXIT_FAILURE, malloc realloc */
#include <string.h>        /* strcat, strlen, strcpy                           */
#include "bubbleShakeQuick.h"
#include "vector.h"

static void swap(Vector* _vec,int i,int j);
static int partition(Vector* _vec,int low, int high);
static ADTErr insertionWithGap(Vector* _vec,int _gap);
static void merge(Vector* _vec,int l,int r);
ADTErr bubbleSort(Vector* _vec)
{
	int i,j,size,aj,ajp1;
	if(NULL==_vec)
	{
		return ERR_NOT_INITIALIZED;
	}
	VectorItemsNum(_vec,&size);
	for(i=1;i<size;i++)
	{
		for(j=1;j<size-i+1;j++)
		{
			VectorGet(_vec,j,&aj);
			VectorGet(_vec,j+1,&ajp1);
			if(aj>ajp1)
			{
				swap(_vec,j,j+1);
			}
		}
	}
	return ERR_OK;
}

ADTErr shakeSort(Vector* _vec)
{
	int i,s,size,ai,aip1,aim1;
	if(NULL==_vec)
	{
		return ERR_NOT_INITIALIZED;
	}
	VectorItemsNum(_vec,&size);
	for(s=1;s<=size/2+1;s++)
	{
		for(i=s-1;i<size-s+1;i++)
		{
			VectorGet(_vec,i,&ai);
			VectorGet(_vec,i+1,&aip1);
			if(ai>aip1)
			{
				swap(_vec,i,i+1);
			}
		}
		for(i=size-s-1;i>=s;i--)
		{
			VectorGet(_vec,i,&ai);
			VectorGet(_vec,i-1,&aim1);
			if(ai<aim1)
			{
				swap(_vec,i,i-1);
			}
		}
		
	}
	return ERR_OK;
}

ADTErr insertionSort(Vector* _vec)
{
	int i,pivot,size,aj,ajp1;
	if(NULL==_vec)
	{
		return ERR_NOT_INITIALIZED;
	}
	insertionWithGap(_vec,1);
}

static ADTErr insertionWithGap(Vector* _vec,int _gap)
{
	int i,j,size,pivot,ai,aj,ajp1;
	VectorItemsNum(_vec,&size);
	for(i=1;i<size;i++)
	{
		VectorGet(_vec,i,&pivot);
		j=i-_gap;
		VectorGet(_vec,j,&aj);		
		while(j>=0 && aj>pivot)
		{
			VectorGet(_vec,j,&ajp1);
			VectorSet(_vec,j+_gap,aj);
			VectorGet(_vec,j,&aj);
		}
		VectorSet(_vec,j+_gap,pivot);
	}
}

ADTErr shellSort(Vector* _vec)
{
	int gap,i,len;
	VectorItemsNum(_vec,&len);
	len=len/2;
	for(gap=len;gap>=1;gap=gap/2)
	{
		insertionWithGap(_vec,gap);
	}
}

static void swap(Vector* _vec,int i,int j)
{
	int index1value,index2value;
	VectorGet(_vec,i,&index1value);
	VectorGet(_vec,j,&index2value);
	VectorSet(_vec,i,index2value);
	VectorSet(_vec,j,index1value);
	return;
}

static int partition(Vector* _vec,int low, int high)
{
	int pivot,i,j,ai,aj,aip1,ah;
	VectorGet(_vec,high,&pivot);
	i=low-1;
	
	for(j=low;j<=high-1;j++)
	{	
		VectorGet(_vec,j,&aj);
		if(aj<=pivot)
		{
			i++;
			VectorGet(_vec,i,&ai);
			swap(_vec,ai,aj);
		}		
	}
	swap(_vec,i+1,high);
	return i+1;
}

ADTErr quickSort(Vector* _vec,int low, int high)
{
	int pi;
	if(NULL==_vec)
	{
		return ERR_NOT_INITIALIZED;
	}
	if(low<high)
	{
		pi=partition(_vec,low,high);
		quickSort(_vec,low,pi-1);
		quickSort(_vec,pi+1,high);
	}	
}

ADTErr selectionSort(Vector* _vec)
{
	int i,j=0,size,aj,min,minIndex=0,aMinIndex;
	if(NULL==_vec)
	{
		return ERR_NOT_INITIALIZED;
	}
	VectorItemsNum(_vec,&size);
	
	for(i=0;i<size;i++)
	{
		VectorGet(_vec,i,&min);
		minIndex=i;
		for(j=i+1;j<size;j++)
		{
			VectorGet(_vec,j,&aj);
			VectorGet(_vec,i,&aMinIndex);
			if(aj<min)
			{
				minIndex=j;
				min=aj;
			}
		}
		swap(_vec,minIndex,i);
	}
}

ADTErr countingSort(Vector* _vec,int range)
{
	int i,num,size,dec;
	int* indexes;
	int* places;
	if(NULL==_vec)
	{
		return ERR_NOT_INITIALIZED;
	}
	indexes=(int*)calloc(range,sizeof(int));
	if(NULL==indexes)
	{
		return ERR_NOT_INITIALIZED;
	}
	VectorItemsNum(_vec,&size);
	places=(int*)calloc(size,sizeof(int));
	if(NULL==places)
	{
		return ERR_NOT_INITIALIZED;
	}

	for(i=0;i<size;i++)
	{
		VectorGet(_vec,i,&num);
		indexes[num]++;
	}
	printf("\n");
	for(i=0;i<range-1;i++)
	{
		indexes[i+1]=indexes[i+1]+indexes[i];
	}
	for(i=0;i<size;i++)
	{
		VectorGet(_vec,i,&dec);
		places[indexes[dec]-1]=dec;
		indexes[dec]--;
	}	
	for(i=0;i<size;i++)
	{
		VectorSet(_vec,i,places[i]);
	}	
}

ADTErr mergeSort(Vector* _vec)
{
	int size,i;
	VectorGet(_vec,i,&size);
	for(i=0;i<size;i++)
	{
		merge(_vec,0,size/2);
		merge(_vec,size/2,size);
		
	}
}

static void merge(Vector* _vec,int l,int r)
{
	
}

void printArr(Vector* _vec)
{
	if(NULL==_vec)
	{
		return;
	}
	VectorPrint(_vec);
}

int isSorted(Vector* _vec)
{
	int i,len,ai,aip1;
	VectorItemsNum(_vec,&len);
	if(len>1)
	for(i=0;i<len-1;i++)
		{
		VectorGet(_vec,i,&ai);
		VectorGet(_vec,i+1,&aip1);
		if(ai>=aip1)			
		{
			return 0;
			break;
		}
	}
	return 1;
}
