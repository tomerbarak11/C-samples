#include "mu_test.h"/*************************************************************************
* 						PROGRAMMER: Tomer Barak
* 						FILE: doublelinked testing
* 						DATE: 02-07-2019 16:18:05
*******************************************************************************/

#include <assert.h>
#include <time.h>
#include <stdlib.h>
#include "vector.h"
#include "bubbleShakeQuick.h"
#include <stdio.h>
#define SIZE1 10000
#define SIZE2 20000
/*
 @author: Muhammad Zahalqa
 @contact: m@tryfinally.com

 ©2019
 μ_test 0.42 demo.

 the directory conatins:
 mu_test.h 		: mu test framework
 funcs.c/h 		: functions to be tested in demo
 test.c 		: test

 Compile with
	gcc -ansi -pedantic -Wall -Wextra funcs.c test.c -o test

 Run:
 	./test
 	./test -v
 */

UNIT(bubble_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i;
	v=VectorCreate(SIZE2,SIZE2);
	srand(time(NULL));
	for(i=0;i<SIZE1;i++)
	{
		VectorAdd(v,rand()%SIZE1);
	}
	bubbleSort(v);
	printf("after\n");
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f",time1);
END_UNIT

UNIT(shake_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i;
	v=VectorCreate(SIZE2,SIZE2);
	srand(time(NULL));
	for(i=0;i<SIZE1;i++)
	{
		VectorAdd(v,rand()%SIZE1);
	}
	shakeSort(v);
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f",time1);
END_UNIT

UNIT(insertion_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i;
	v=VectorCreate(SIZE2,SIZE2);
	srand(time(NULL));
	for(i=0;i<SIZE1;i++)
	{
		VectorAdd(v,rand()%SIZE1);
	}
	insertionSort(v);
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f",time1);
END_UNIT

UNIT(shell_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i,flag,ai,aip1,len;
	flag=1;
	v=VectorCreate(SIZE2,SIZE2);
	VectorAdd(v,77);
	VectorAdd(v,62);
	VectorAdd(v,14);
	VectorAdd(v,9);
	VectorAdd(v,30);
	VectorAdd(v,21);
	VectorAdd(v,80);
	VectorAdd(v,25);
	VectorAdd(v,70);
	VectorAdd(v,55);
	shellSort(v);
	VectorItemsNum(v,&len);
	if(len>1)
	{
		for(i=0;i<len-1;i++)
		{
			VectorGet(v,i,&ai);
			VectorGet(v,i+1,&aip1);
			if(ai>=aip1)			
			{
				flag=0;
				break;
			}
		}
	}
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f\n",time1);
	ASSERT_THAT(flag==1);
END_UNIT

UNIT(quick_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i;
	v=VectorCreate(SIZE2,SIZE2);
	srand(time(NULL));
	for(i=0;i<SIZE1;i++)
	{
		VectorAdd(v,rand()%SIZE1);
	}
	quickSort(v,0,SIZE1-1);
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f",time1);
END_UNIT

UNIT(selection_sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i;
	v=VectorCreate(10,10);
	srand(time(NULL));
	VectorAdd(v,9);
	VectorAdd(v,62);
	VectorAdd(v,77);
	VectorAdd(v,62);
	VectorAdd(v,14);
	VectorAdd(v,9);
	VectorAdd(v,30);
	VectorAdd(v,21);
	VectorAdd(v,80);
	VectorAdd(v,25);
	VectorAdd(v,70);
	VectorAdd(v,55);
	selectionSort(v);
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f\n",time1);
	VectorPrint(v);
END_UNIT

UNIT(counting_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i,len,ai,aip1;
	v=VectorCreate(10,10);
	srand(time(NULL));
	VectorAdd(v,1);
	VectorAdd(v,4);
	VectorAdd(v,1);
	VectorAdd(v,2);
	VectorAdd(v,7);
	VectorAdd(v,5);
	VectorAdd(v,2);
	VectorPrint(v);
	printf("\n");
	countingSort(v,10);

	flag=isSorted(v);
	ASSERT_THAT(flag==1);
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f\n",time1);
	VectorPrint(v);
END_UNIT

UNIT(merge_Sort)
	clock_t t=clock();
	Vector* v;
	double time1;
	int i;
	v=VectorCreate(10,10);
	srand(time(NULL));
	VectorAdd(v,1);
	VectorAdd(v,4);
	VectorAdd(v,1);
	VectorAdd(v,7);
	VectorAdd(v,5);
	VectorAdd(v,2);
	VectorPrint(v);
	printf("\n");
	mergeSort(v);
	time1=(double)(clock()-t)/CLOCKS_PER_SEC;
	printf("the time is: %f\n",time1);
	VectorPrint(v);
END_UNIT

TEST_SUITE(Dynamic Vector Module Unit Test)
	/*TEST(bubble_Sort)
	TEST(shake_Sort)
	TEST(insertion_Sort)
	TEST(shell_Sort)
	TEST(quick_Sort)
	TEST(selection_sort)
	TEST(counting_Sort)*/
	TEST(merge_Sort)
END_SUITE
